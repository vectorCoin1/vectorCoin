Vector Coin is a coin created as a joke. Vector in this application isn't a math term, but rather Vector from Despicable Me.

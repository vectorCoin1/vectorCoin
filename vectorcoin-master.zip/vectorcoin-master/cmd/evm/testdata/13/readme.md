## Input transactions in RLP form

This testdata folder is used to examplify how transaction input can be provided in rlp form. 
Please see the README in `evm` folder for how this is performed. 